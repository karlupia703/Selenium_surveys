package coding;

import java.util.Scanner;

 class FirstProgram {
//	static void myMethod() {
//		System.out.println("hello");
//	}
//	 public static void main(String[] args) {
//	 myMethod();
//	 }			 
		 
	
// method print from different way
	
	public static void main(String[] args){
		Scanner myobj = new Scanner(System.in);
		String userName;
	
		//enter username and press enter
		System.out.println("Enter usernamee");
		userName = myobj.nextLine();
		
		System.out.println("Username is:" + userName);
	}
      	
    }
	 

		 
		 
	 
	//	    if (40>=18) 
		 
//			 int x = 15;
//			 int y = 20;
//		     if (x<y)	 
//		    	System.out.println("X is less than Y");
			 
//			int time =20;
//			if (time<18) {
//			System.out.println("Good morning");	
//		
//			}
//			else {
//				System.out.println("Good Evening");				
//			}
			 
//	      int time = 22;
//	      if (time<10) {
//		   System.out.println("Good morning");	
//	      }
//		  else if (time<18) {
//		 System.out.println("Good day");	
//		  }
//		  else {
//		 System.out.println("Good evening");	
//  		  }
	      
//			 int myNum = 0; // Is this a positive or negative number?
//
//			 if (myNum > 0) {
//			   System.out.println("The value is a positive number.");
//			 } else if (myNum < 0) {
//			   System.out.println("The value is a negative number.");
//			 } else {
//			   System.out.println("The value is 0.");
//			 }
//	      
			 
//			int a = 19;
//			int b = 5;
//			
//		if (a<=b) {
//			System.out.println("a is less than b");
//		}
//		else if (a==b) {
//		 System.out.println("a is greater and equal than b");
//		}
//		else {
//			System.out.println("b is greater");
//		  }
//	
//			 int i = 2;
//			    do {
//			      System.out.println(i);
//			      i++;
//			    }
//			    while (i < 7);
//			    
//			    // reversing a string
//			    String s = "Hello there";
//			    int len = s.length();
//			    for(int j=len-1 ; j >=0; j--) {
//			    	System.out.print(s.charAt(j));
//			    }
			    
//			    int i =1;
//			    do {
//			    System.out.println(i);
//			    i++;
//			    }
//			    while (i<9);
//			
//		 		 		int countdown = 3;
//
//			    while (countdown > 0) {
//			      System.out.println(countdown);
//		      countdown--;
//		    } 
//			    System.out.println("Happy New Year 2025!!");	
//	 }
		 
		 
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
	    


		 
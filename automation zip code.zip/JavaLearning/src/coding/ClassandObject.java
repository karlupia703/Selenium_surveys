package coding;



   // non parameters pass in constructor
//public class ClassandObject {
//	String color;
//	String type;
//	
//	public void write() {
//	System.out.println("Writing something");
//	}
//
//	//i want to print the color of pen
//	public void Colorprint() {
//		System.out.println(this.color);
//	}
//	
//	public static void main(String[] args) {
//		ClassandObject pen1 = new ClassandObject();
//		pen1.color ="blue";
//		pen1.type ="gel";
//		
//		pen1.write(); // call to print writing something
//		
//		ClassandObject pen2 = new ClassandObject();
//		pen2.color = "black";
//		pen2.type = "ballpoint";
//		
//		pen1.Colorprint(); //blue
//	    pen2.Colorprint(); //black print hoga
//	    



	  // Constructor call with parameters	
// public class ClassandObject {
// String name;
// int age;
// String profession;
// 
//   public void studentinfo() {
//	   System.out.println(this.name);
//	   System.out.println(this.age);
//	   System.out.println(this.profession);
//   }
//	 
//   ClassandObject(String name, int age, String profession){
//	   this.name = name;
//	   this.age = age;
//	   this.profession = profession;
//	   
//   }
//     
//	 public static void main(String[] args) {
//		 ClassandObject S1 = new ClassandObject("Raman", 23,"QA");
//		 S1.studentinfo();
//		 		 
// }
// }
//	
 
 


public class ClassandObject {
int x= 5;
int y = 10;

public static void main(String[] args) {
ClassandObject myobj1 = new ClassandObject();
	ClassandObject myobj2 = new ClassandObject();
System.out.println(myobj1.x);
System.out.println(myobj2.y);
}
}
 

               //Inheritance


 
	
	
	
	
	
	
	
	
		
	



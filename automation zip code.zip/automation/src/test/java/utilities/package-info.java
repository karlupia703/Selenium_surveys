package utilities;
import java.util.Scanner;

class Newinfo{
public static void main(String[] args){
	Scanner myobj1 = new Scanner(System.in);
	String Name;

	//enter username and press enter
	System.out.println("My name is Riya");
	Name = myobj1.nextLine();
	
	System.out.println("Username is:" + Name);
}
  	
}
 
package java.lang.reflect;

public class Method {

	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

}
